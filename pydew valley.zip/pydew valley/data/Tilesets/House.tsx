<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.8" tiledversion="1.8.6" name="House" tilewidth="64" tileheight="64" tilecount="35" columns="7">
 <image source="../../graphics/environment/House.png" width="448" height="320"/>
</tileset>
